# Icloud-login-clone

ICloud Login Clone, use of POST method for credentials inputs.

INFOS :
* `name` attribute is mandatory in `<input>` for correct credentials display

Created by MadHippo
